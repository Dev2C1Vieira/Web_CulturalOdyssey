export const getError = (error: any): string | void => {
  const _error = error.toString();

  if (_error.includes('auth/email-already-in-use')) {
    return 'auth/email-already-in-use';
  }
};

export const validateEmail = (email: string): boolean => {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
};
