import { Component } from '@angular/core';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrl: './dashboard.component.css',
})
export class DashboardComponent {
    isCollapsed: boolean = false;

  items = [
    { icon: 'fas fa-home', label: 'Home' },
    { icon: 'fas fa-user', label: 'Profile' },
    { icon: 'fas fa-cog', label: 'Settings' }
    // Add more items as needed
  ];

  toggleSidebar() {
    this.isCollapsed = !this.isCollapsed;
  }
}
