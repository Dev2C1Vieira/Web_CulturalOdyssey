export const firebaseConfig = {
  apiKey: 'AIzaSyBKbd5o7BS7PZNpUICm51sEngC4WvRBZ3Q',
  authDomain: 'cultural-odyssey.firebaseapp.com',
  databaseURL:
    'https://cultural-odyssey-default-rtdb.europe-west1.firebasedatabase.app',
  projectId: 'cultural-odyssey',
  storageBucket: 'cultural-odyssey.appspot.com',
  messagingSenderId: '101401585892',
  appId: '1:101401585892:web:25474270dff5d7da2624f1',
  measurementId: 'G-DNG4N2WSJR',
};
